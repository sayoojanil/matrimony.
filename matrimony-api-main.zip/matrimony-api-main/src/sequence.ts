import {AuthenticateFn, AuthenticationBindings} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {FindRoute, InvokeMethod, ParseParams, Reject, RequestContext, Response, RestBindings, Send, SequenceHandler} from '@loopback/rest';
import {SecurityBindings} from '@loopback/security';

const SequenceActions = RestBindings.SequenceActions;

export class MySequence implements SequenceHandler {
  constructor(
    @inject(SequenceActions.FIND_ROUTE) protected findRoute: FindRoute,
    @inject(SequenceActions.PARSE_PARAMS) protected parseParams: ParseParams,
    @inject(SequenceActions.INVOKE_METHOD) protected invoke: InvokeMethod,
    @inject(SequenceActions.SEND) public send: Send,
    @inject(SequenceActions.REJECT) public reject: Reject,
    @inject(AuthenticationBindings.AUTH_ACTION) protected authenticateRequest: AuthenticateFn,
    @inject(RestBindings.Http.RESPONSE) protected response: Response,
  ) { }

  async handle(context: RequestContext) {
    try {
      const {request, response} = context;
      const route = this.findRoute(request);

      // Skip authentication for public endpoints
      const publicEndpoints = [
        '/user/login',
        '/users/verifyOtp',
        '/ping', // Optional: for testing
      ];
      const isPublicEndpoint = publicEndpoints.some(endpoint =>
        request.url.startsWith(endpoint) || request.url === endpoint
      );

      if (!isPublicEndpoint) {
        // Authenticate only for non-public endpoints
        const userProfile = await this.authenticateRequest(request);
        if (userProfile) {
          // Bind user profile to request context
          context.bind(SecurityBindings.USER).to(userProfile);
        }
      }

      const args = await this.parseParams(request, route);
      const result = await this.invoke(route, args);
      this.send(response, result);
    } catch (err) {
      this.response.status(401).send({error: 'Unauthorized'});
      this.reject(context, err);
    }
  }
}
