import {belongsTo, Entity, model, property} from '@loopback/repository';
import {Profile} from './profile.model';

@model()
export class Feedback extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  title?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
  })
  type?: string;

  @property({
    type: 'string',
  })
  reply?: string;

  // @belongsTo(() => AdminMaster)
  @property({
    type: 'string',
  })
  replyId: string;

  @belongsTo(() => Profile)
  customerId: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;

  constructor(data?: Partial<Feedback>) {
    super(data);
  }
}

export interface FeedbackRelations {
  // describe navigational properties here
}

export type FeedbackWithRelations = Feedback & FeedbackRelations;
