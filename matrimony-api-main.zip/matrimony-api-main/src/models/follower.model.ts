import {belongsTo, Entity, model, property} from '@loopback/repository';
import {Profile} from './profile.model';

@model()
export class Follower extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;


  @belongsTo(() => Profile)
  followerId?: string; // ID of the user who is following


  @belongsTo(() => Profile)
  followedId?: string; // ID of the user being followed

  @property({
    type: 'date',
    default: () => new Date(),
  })
  createdAt?: Date;

  constructor(data?: Partial<Follower>) {
    super(data);
  }
}

export interface FollowerRelations {
  // describe navigational properties here
}

export type FollowerWithRelations = Follower & FollowerRelations;
