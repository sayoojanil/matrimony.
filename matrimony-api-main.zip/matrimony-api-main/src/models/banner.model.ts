import {Entity, model, property} from '@loopback/repository';

@model()
export class Banner extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  title?: string;

  @property({
    type: 'string',
    required: true,
  })
  image: string;

  @property({
    type: 'number',
    default: 1,
  })
  order?: number;

  @property({
    type: 'number',
    default: 1,
  })
  active?: number;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  startDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  endDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;


  constructor(data?: Partial<Banner>) {
    super(data);
  }
}

export interface BannerRelations {
  // describe navigational properties here
}

export type BannerWithRelations = Banner & BannerRelations;
