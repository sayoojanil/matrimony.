import {Entity, belongsTo, model, property} from '@loopback/repository';
import {FeedPost} from './feed-post.model';

@model()
export class FeedPostImage extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  url?: string;

  @property({
    type: 'string',
  })
  bucketKey?: string;

  @property({
    type: 'number',
  })
  order?: number;

  @property({
    type: 'boolean',
    default: false
  })
  hidden?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;

  @belongsTo(() => FeedPost)
  feedPostId: string;
  // @hasMany(() => FeedPost)
  // feedposts: FeedPost[];

  constructor(data?: Partial<FeedPostImage>) {
    super(data);
  }
}

export interface FeedPostImageRelations {
  // describe navigational properties here
}

export type FeedPostImageWithRelations = FeedPostImage & FeedPostImageRelations;
