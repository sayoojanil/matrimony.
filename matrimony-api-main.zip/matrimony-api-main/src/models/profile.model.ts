import {Entity, model, property} from '@loopback/repository';

@model()
export class Profile extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })

  id?: string;
  @property({
    type: 'string',
    required: true,
  })
  name?: string;


  @property({
    type: 'string',
  })
  phone?: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
  })
  role?: string;

  @property({
    type: 'string',
  })
  location?: string;

  @property({
    type: 'string',
  })
  youtubeLink?: string;

  @property({
    type: 'string',
  })
  height?: string;

  @property({
    type: 'string',
  })
  weight?: string;

  @property({
    type: 'string',
  })
  experience?: string;
  @property({
    type: 'string',
  })
  primaryLanguage?: string;

  @property({
    type: 'string',
  })
  interfaceLanguage?: string;

  @property({
    type: 'array',
    itemType: 'string'
  })
  additionalLanguages?: string[];

  @property({
    type: 'date',
  })
  dob?: string;

  @property({
    type: 'string',
  })
  gender?: string;

  @property({
    type: 'string',
  })
  countryCode?: string;

  @property({
    type: 'number',
    default: 0
  })
  postCount?: number;

  @property({
    type: 'number',
    default: 0
  })
  following?: number;

  @property({
    type: 'number',
    default: 0
  })
  followers?: number;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;


  constructor(data?: Partial<Profile>) {
    super(data);
  }
}

export interface ProfileRelations {
  // describe navigational properties here
}

export type ProfileWithRelations = Profile & ProfileRelations;
