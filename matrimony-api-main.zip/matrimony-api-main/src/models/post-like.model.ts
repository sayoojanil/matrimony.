import {belongsTo, Entity, model, property} from '@loopback/repository';
import {FeedPost} from './feed-post.model';
import {Profile} from './profile.model';

@model()
export class PostLike extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  type?: string;

  @belongsTo(() => FeedPost)
  feedPostId?: string;


  @belongsTo(() => Profile)
  userId?: string;

  constructor(data?: Partial<PostLike>) {
    super(data);
  }
}

export interface PostLikeRelations {
  // describe navigational properties here
}

export type PostLikeWithRelations = PostLike & PostLikeRelations;
