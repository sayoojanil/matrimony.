import {model} from '@loopback/repository';

@model()
export class CustomResponse {
  success: boolean;
  message: string;
  type: string;
  data: any;

  constructor(response?: Partial<CustomResponse>) {
    if (response != null) {
      response.success = response.success != null ? response.success : false;
      response.message = response.message != null ? response.message : 'Success';
      response.type = response.type != null ? response.type : '';
      response.data = response.data != null ? response.data : null;
    } else {
      response = {};
      response.success = false;
      response.message = 'Error';
      response.type = '';
      response.data = null;
    }
    Object.assign(this, response);

  }
}
