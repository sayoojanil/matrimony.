import {belongsTo, Entity, model, property} from '@loopback/repository';
import {FeedPost} from './feed-post.model';
import {Profile} from './profile.model';

@model()
export class PostComment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  content?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;

  @belongsTo(() => Profile)
  userId: string;

  @belongsTo(() => FeedPost)
  feedPostId: string;

  constructor(data?: Partial<PostComment>) {
    super(data);
  }
}

export interface ReviewRelations {
  // describe navigational properties here
}

export type ReviewWithRelations = PostComment & ReviewRelations;
