import {belongsTo, Entity, hasMany, model, property} from '@loopback/repository';
import {FeedPostImage} from './feed-post-image.model';
import {PostComment} from './post-comment.model';
import {PostLike} from './post-like.model';
import {Profile} from './profile.model';

@model()
export class FeedPost extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  title?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => FeedPostImage)
  images: FeedPostImage[];

  @property({
    type: 'number',
    default: () => 1
  })
  status?: number;

  @property({
    type: 'number',
    default: () => 0
  })

  likesCount?: number;
  @property({
    type: 'number',
    default: () => 0
  })
  commentsCount?: number;

  @belongsTo(() => Profile)
  userId: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated: string;

  @hasMany(() => PostLike)
  likes: PostLike[];

  @hasMany(() => PostComment)
  comments: PostComment[];

  @hasMany(() => Profile, {through: {model: () => PostLike, keyTo: 'userId', keyFrom: 'feedPostId'}})
  likedUsers: Profile[];

  constructor(data?: Partial<FeedPost>) {
    super(data);
  }
}

export interface FeedPostRelations {
  // describe navigational properties here
}

export type FeedPostWithRelations = FeedPost & FeedPostRelations;


@model()
export class FeedPostInsert extends Entity {
  @property({
    type: 'object',
  })
  feedpost?: FeedPost;

  @property({
    type: 'string',
  })
  userId?: string;


  @property({
    type: 'array',
    itemType: 'string'
  })
  images?: string[];
}
