import {Entity, model, property} from '@loopback/repository';

@model()
export class AdminMaster extends Entity {

  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name?: string;
  @property({
    type: 'string',
  })
  phone?: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'string',
  })
  countryCode?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'boolean',
    default: false
  })
  userAccess?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  editItem?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  editPlan?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  editPromotion?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  approval?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  newsfeed?: boolean;

  @property({
    type: 'number',
    default: 1
  })
  status?: number;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;


  constructor(data?: Partial<AdminMaster>) {
    super(data);
  }
}

export interface AdminMasterRelations {
  // describe navigational properties here
}

export type AdminMasterWithRelations = AdminMaster & AdminMasterRelations;
