import {Entity, belongsTo, model, property} from '@loopback/repository';
import {Portfolio} from './portfolio.model';

@model()
export class PortfolioImage extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  url?: string;

  @property({
    type: 'string',
  })
  bucketKey?: string;

  @property({
    type: 'number',
  })
  order?: number;

  @property({
    type: 'boolean',
    default: false
  })
  hidden?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated?: string;

  @belongsTo(() => Portfolio)
  portfolioId: string;
  // @hasMany(() => FeedPost)
  // feedposts: FeedPost[];

  constructor(data?: Partial<PortfolioImage>) {
    super(data);
  }
}

export interface PortfolioImageRelations {
  // describe navigational properties here
}

export type PortfolioImageWithRelations = PortfolioImage & PortfolioImageRelations;
