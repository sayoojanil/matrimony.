import {belongsTo, Entity, hasMany, model, property} from '@loopback/repository';
import {PortfolioImage} from './portfolio-image.model';
import {Profile} from './profile.model';

@model()
export class Portfolio extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  title?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => PortfolioImage)
  images: PortfolioImage[];

  @property({
    type: 'number',
    default: () => 1
  })
  status?: number;
  @property({
    type: 'number',
    default: () => 0
  })
  likesCount?: number;

  @belongsTo(() => Profile)
  profileId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    jsonSchema: {
      format: 'date',
    },
  })
  dateCreated: string;

  constructor(data?: Partial<Portfolio>) {
    super(data);
  }
}

export interface FeedPostRelations {
  // describe navigational properties here
}

export type FeedPostWithRelations = Portfolio & FeedPostRelations;


@model()
export class FeedPostInsert extends Entity {
  @property({
    type: 'object',
  })
  feedpost?: Portfolio;

  @property({
    type: 'string',
  })
  userId?: string;


  @property({
    type: 'array',
    itemType: 'string'
  })
  images?: string[];
}
