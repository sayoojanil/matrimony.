import {Entity, model, property} from '@loopback/repository';

@model()
export class MasterOption extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  name?: string;

  constructor(data?: Partial<MasterOption>) {
    super(data);
  }
}

@model()
export class ItemStatus extends MasterOption {

}

export interface MasterOptionRelations {
  // describe navigational properties here
}

export type MasterOptionWithRelations = MasterOption & MasterOptionRelations;
