export class Constants {

  static getMaterialType: any = new Map([

  ]);
}
