import {Provider, inject} from '@loopback/core';
import {RequestContext, Response, RestBindings, Send} from '@loopback/rest';

export class MYSuccessHandlerProvider implements Provider<Send> {
  constructor(
    @inject(RestBindings.Http.CONTEXT) private context: RequestContext
  ) { }

  value(): Send {
    return async (response: Response, result: unknown) => {
      const req = await this.context.get<{url: string}>('rest.http.request');

      // Skip formatting if accessing explorer or static files
      if (req.url.startsWith('/explorer') || req.url.startsWith('/openapi')) {
        if (!response.headersSent) {
          response.send(result);
        }
        return;
      }
      let customMessage = 'Successful';
      try {
        customMessage = await this.context.get<string>('response.message');
      } catch {
        // No custom message set — use default
      }

      if (typeof result === 'object' && result !== null && (result as any).success !== true) {
        // Format only if not already formatted
        result = {
          success: true,
          data: result,
          message: customMessage,
          timestamp: new Date().toISOString(),
        };
      }
      if (!response.headersSent) {
        response.json(result);
      }
    };
  }
}
