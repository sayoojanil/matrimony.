// src/providers/my-error-handler.provider.ts
import {
  inject,
  Provider
} from '@loopback/core';
import {
  HandlerContext,
  HttpErrors,
  Reject,
  Request,
  RequestContext,
  Response,
  RestBindings
} from '@loopback/rest';

export class MyErrorHandlerProvider implements Provider<Reject> {
  constructor(
    @inject(RestBindings.Http.REQUEST) private request: Request,
    @inject(RestBindings.Http.RESPONSE) private response: Response,
    @inject(RestBindings.Http.CONTEXT) private context: RequestContext
  ) { }

  value(): Reject {
    return (context, err) => this.handle(context, err);
  }
  async handle(context: HandlerContext, err: unknown) {
    let data = null;
    try {
      data = await this.context.get<Map<string, any>>('response.data');
    } catch {
      // No custom message set — use default
    }
    const httpError = err as HttpErrors.HttpError;
    const statusCode = httpError.statusCode || 500;
    const errorResponse = {
      success: false,
      message: httpError.message,
      data: data,
      error: {
        code: statusCode,
        name: httpError.name,
        path: this.request.path,
        timestamp: new Date().toISOString()
      }
    };

    this.response.status(statusCode).json(errorResponse);
  }
}
