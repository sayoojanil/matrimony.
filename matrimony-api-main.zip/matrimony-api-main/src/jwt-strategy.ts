import {AuthenticationStrategy} from '@loopback/authentication';
import {TokenServiceBindings} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {Request} from '@loopback/rest';
import {securityId, UserProfile} from '@loopback/security';
import {verify} from 'jsonwebtoken';
import {UserRepository} from './repositories/user.repository';

export class JWTAuthenticationStrategy implements AuthenticationStrategy {
  name = 'jwt';

  constructor(
    @inject(TokenServiceBindings.TOKEN_SERVICE) private jwtSecret: string,
    @repository(UserRepository) private userRepository: UserRepository,
  ) { }

  async authenticate(request: Request): Promise<UserProfile | undefined> {
    const token: string = this.extractToken(request);
    try {
      console.log('this.jwtSecret');
      console.log(this.jwtSecret);
      //todo need to change this
      const payload = verify(token, 'your_jwt_secret') as UserProfile;
      console.log(payload);
      console.log(payload.sub);
      const user = await this.userRepository.findById(payload.id);
      if (!user) {
        throw new Error('User not found');
      }
      return {[securityId]: user.id, email: user.email};
    } catch (err) {
      console.log(err);
      throw new Error('Invalid token');
    }
  }

  extractToken(request: Request): string {
    const authHeader = request.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new Error('Authorization header missing or invalid');
    }
    return authHeader.replace('Bearer ', '');
  }
}
