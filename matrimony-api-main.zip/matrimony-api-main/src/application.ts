import {AuthenticationComponent, registerAuthenticationStrategy} from '@loopback/authentication';
import {JWTService, TokenServiceBindings, UserServiceBindings} from '@loopback/authentication-jwt';
import {BootMixin} from '@loopback/boot';
import {ApplicationConfig} from '@loopback/core';
import {RepositoryMixin} from '@loopback/repository';
import {RestApplication, RestBindings, SequenceActions} from '@loopback/rest';
import {RestExplorerBindings, RestExplorerComponent} from '@loopback/rest-explorer';
import {ServiceMixin} from '@loopback/service-proxy';
import path from 'path';
import {DbDataSource} from './datasources/db.datasource';
import {JWTAuthenticationStrategy} from './jwt-strategy';
import {FeedPostRepository, ProfileRepository} from './repositories';
import {FollowerRepository} from './repositories/follower.repository';
import {UserRepository} from './repositories/user.repository';
import {MySequence} from './sequence';
import {MyErrorHandlerProvider} from './services/error-handler';
import {PasswordService} from './services/password.service';
import {MYSuccessHandlerProvider} from './services/success-handler';
import {CustomUserService} from './services/user.service';
export {ApplicationConfig};
export class CinemateApplication extends BootMixin(
  ServiceMixin(RepositoryMixin(RestApplication)),
) {
  constructor(options: ApplicationConfig = {}) {
    super(options);

    this.bind(SequenceActions.REJECT).toProvider(MyErrorHandlerProvider);
    this.bind(SequenceActions.SEND).toProvider(MYSuccessHandlerProvider);
    // Add authentication component
    this.component(AuthenticationComponent);


    // Add REST explorer component
    this.component(RestExplorerComponent);

    this.static('/', path.join(__dirname, '../public'));

    // Customize @loopback/rest-explorer configuration here
    this.configure(RestExplorerBindings.COMPONENT).to({
      path: '/explorer',
    });

    // Bind custom sequence
    this.bind(RestBindings.SEQUENCE).toClass(MySequence);

    // Bind JWT services
    this.bind(TokenServiceBindings.TOKEN_SERVICE).toClass(JWTService);
    this.bind(UserServiceBindings.USER_SERVICE).toClass(CustomUserService);

    registerAuthenticationStrategy(this, JWTAuthenticationStrategy);
    // Bind JWT secret (use environment variable in production)
    // this.bind('jwt.secret').to('your-secret-key');

    this.dataSource(DbDataSource, UserServiceBindings.DATASOURCE_NAME);
    // Bind password service
    this.bind('services.PasswordService').toClass(PasswordService);
    // Configure JWT secret and expiry
    this.bind(TokenServiceBindings.TOKEN_SECRET).to(process.env.JWT_SECRET || 'your_jwt_secret');
    this.bind(TokenServiceBindings.TOKEN_EXPIRES_IN).to('360000');

    // Bind repositories
    this.repository(UserRepository);
    this.repository(ProfileRepository);
    this.repository(FollowerRepository);
    this.repository(FeedPostRepository);

    // Set up project
    this.projectRoot = __dirname;
    this.bootOptions = {
      controllers: {
        dirs: ['controllers'],
        extensions: ['.controller.js', '.controller.ts'],
        nested: true,
      },
    };
  }
}
