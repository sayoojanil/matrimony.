import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {PostLike, PostLikeRelations} from '../models';

export class PostLikeRepository extends DefaultCrudRepository<
  PostLike,
  typeof PostLike.prototype.id,
  PostLikeRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(PostLike, dataSource);
  }
}
