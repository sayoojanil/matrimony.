import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {ItemStatus, MasterOptionRelations} from '../models';


export class ItemStatusRepository extends DefaultCrudRepository<
  ItemStatus,
  typeof ItemStatus.prototype.id,
  MasterOptionRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(ItemStatus, dataSource);
  }
}

