import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {AdminMaster, AdminMasterRelations, Profile} from '../models';

export class AdminRepository extends DefaultCrudRepository<
  AdminMaster,
  typeof Profile.prototype.id,
  AdminMasterRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(AdminMaster, dataSource);
  }
}
