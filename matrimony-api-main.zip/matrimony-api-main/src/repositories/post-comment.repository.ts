import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {PostComment, Profile, ReviewRelations} from '../models';
import {ProfileRepository} from './profile.repository';

export class PostCommentRepository extends DefaultCrudRepository<
  PostComment,
  typeof PostComment.prototype.id,
  ReviewRelations
> {

  public readonly user: BelongsToAccessor<Profile, typeof PostComment.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProfileRepository') protected userRepositoryGetter: Getter<ProfileRepository>,
  ) {
    super(PostComment, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter,);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
