import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, HasManyRepositoryFactory, HasManyThroughRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {FeedPost, FeedPostImage, FeedPostImageRelations, FeedPostRelations, PostLike, Profile} from '../models';
import {PostLikeRepository} from './post-like.repository';
import {ProfileRepository} from './profile.repository';

export class FeedPostRepository extends DefaultCrudRepository<
  FeedPost,
  typeof FeedPost.prototype.id,
  FeedPostRelations
> {
  public readonly images: HasManyRepositoryFactory<FeedPostImage, typeof FeedPost.prototype.id>;
  public readonly likes: HasManyRepositoryFactory<PostLike, typeof FeedPost.prototype.id>;
  public readonly user: BelongsToAccessor<Profile, typeof FeedPost.prototype.id>;

  public readonly likedUsers: HasManyThroughRepositoryFactory<Profile, typeof Profile.prototype.id,
    PostLike,
    typeof FeedPost.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('FeedPostImageRepository') protected feedPostImageRepository: Getter<FeedPostImageRepository>,
    @repository.getter('PostLikeRepository') protected postLikeRepositoryGetter: Getter<PostLikeRepository>,
    @repository.getter('ProfileRepository') protected profileRepositoryGetter: Getter<ProfileRepository>,
  ) {
    super(FeedPost, dataSource);
    this.likedUsers = this.createHasManyThroughRepositoryFactoryFor('likedUsers', profileRepositoryGetter, postLikeRepositoryGetter,);
    this.registerInclusionResolver('likedUsers', this.likedUsers.inclusionResolver);
    this.images = this.createHasManyRepositoryFactoryFor('images', feedPostImageRepository,);
    this.registerInclusionResolver('images', this.images.inclusionResolver);
    this.likes = this.createHasManyRepositoryFactoryFor('likes', postLikeRepositoryGetter,);
    this.registerInclusionResolver('likes', this.likes.inclusionResolver);
    this.user = this.createBelongsToAccessorFor('user', profileRepositoryGetter,);
    this.registerInclusionResolver('user', this.user.inclusionResolver);

    // ----- Virtual Inclusion Resolver for hasLiked -----
    /* this.registerInclusionResolver('hasLiked', async (entities, inclusion, options) => {
      const userId = options?.userId;
      if (!userId) {
        // If no userId is provided, return null for all
        return entities.map(() => null);
      }

      const postIds = entities.map(post => post.id);

      const postLikeRepo = await this.postLikeRepositoryGetter();

      const likes = await postLikeRepo.find({
        where: {
          feedPostId: {inq: postIds},
          userId,
        },
      });

      const likeMap = new Map<string, PostLike>();
      likes.forEach(like => {
        likeMap.set(like.feedPostId.toString(), like);
      });

      return entities.map(entity => likeMap.get(entity.id.toString()) || null);
    }); */
  }
}

export class FeedPostImageRepository extends DefaultCrudRepository<
  FeedPostImage,
  typeof FeedPostImage.prototype.id,
  FeedPostImageRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(FeedPostImage, dataSource);
  }
}
