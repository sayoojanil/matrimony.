import {TokenService} from '@loopback/authentication';
import {TokenServiceBindings, UserServiceBindings} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {post} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {CustomResponse} from '../models/response.model';
import {UserRepository} from '../repositories/user.repository';
import {CustomUserService} from '../services/user.service';

export class CommonController {
  constructor(
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: TokenService,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: CustomUserService,
    @inject(SecurityBindings.USER, {optional: true})
    public user: UserProfile,
    @repository(UserRepository)
    public userRepository: UserRepository,
  ) { }

  @post('/common/getCarousel')
  async getCarousel(): Promise<CustomResponse> {
    var data = [{
      name: "one",
      image: "https://media.istockphoto.com/id/1093110112/photo/picturesque-morning-in-plitvice-national-park-colorful-spring-scene-of-green-forest-with-pure.jpg?s=612x612&w=0&k=20&c=lpQ1sQI49bYbTp9WQ_EfVltAqSP1DXg0Ia7APTjjxz4="
    },
    {
      name: "two",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCZlf5lc5tX-0gY-y94pGS0mQdL-D0lCH2OQ&usqp=CAU"
    },
    {
      name: "three",
      image: "https://img.freepik.com/free-photo/painting-mountain-lake-with-mountain-background_188544-9126.jpg?q=10&h=200"
    },]
    const response = new CustomResponse({success: true, data: data});
    return response;
  }
}
