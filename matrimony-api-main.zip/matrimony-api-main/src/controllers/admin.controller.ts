import {UserRepository} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  requestBody,
  RequestContext,
  response,
  RestBindings
} from '@loopback/rest';
import {AdminMaster, Profile} from '../models';
import {AdminRepository} from '../repositories/admin.repository';

export class AdminController {
  constructor(
    @repository(AdminRepository)
    public adminRepository: AdminRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext,
  ) { }

  @get('/getAdmins')
  @response(200, {
    description: 'Array of Customer model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Profile, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Profile) filter?: Filter<Profile>,
  ): Promise<Profile[]> {
    var res = await this.adminRepository.find(filter);
    return res;
  }

  @patch('/updateAllAdmin')
  @response(200, {
    description: 'Customer PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AdminMaster, {partial: true}),
        },
      },
    })
    customer: AdminMaster,
    @param.where(AdminMaster) where?: Where<AdminMaster>,
  ): Promise<{count: number}> {
    var res = await this.adminRepository.updateAll(customer, where);
    this.ctx.bind('response.message').to('Admins updated successfully');
    return res;
  }

  @get('/getAdmin/{id}')
  @response(200, {
    description: 'Customer model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Profile, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Profile, {exclude: 'where'}) filter?: FilterExcludingWhere<Profile>
  ): Promise<Profile> {
    var res = await this.adminRepository.findById(id, filter);
    return res;
  }

  @del('/deleteAdmin/{id}')
  @response(204, {
    description: 'Customer DELETE success',
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    var res = await this.adminRepository.findById(id);
    await this.adminRepository.deleteById(id);
    await this.userRepository.deleteById(res.userId!);
    this.ctx.bind('response.message').to('User deleted successfully');
    return;
  }
}
