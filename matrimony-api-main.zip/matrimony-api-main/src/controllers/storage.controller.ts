/* import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {get, param, post, requestBody} from '@loopback/rest';


import {Request, Response, RestBindings, del} from '@loopback/rest';
import AWS from 'aws-sdk';

import HttpErrors from 'http-errors';
import multer from 'multer';
import stream from 'stream';
import {ItemImage} from '../models';
import {CustomResponse} from '../models/response.model';
const {Duplex} = stream

function bufferToStream(buffer: any) {
  const duplexStream = new Duplex()
  duplexStream.push(buffer)
  duplexStream.push(null)
  return duplexStream
}

const config = {
  region: "ap-south-1",
  accessKeyId: "AKIAUXFDMRPZWK5TV5XF",
  secretAccessKey: "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",
}
const s3 = new AWS.S3(config)

export class StorageController {
  constructor(
    @repository(ItemImageRepository)
    public itemImageRepository: ItemImageRepository,
    @repository(MerchantRepository)
    public merchantRepository: MerchantRepository,
  ) { }

  @get('/buckets', {
    responses: {
      '200': {
        description: 'List of buckets',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                Name: {type: 'string'},
                CreationDate: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  async list(): Promise<object> {
    try {
      const buckets = await s3.listBuckets().promise()
      return buckets
    } catch (err) {
      throw (err)
    }
  }

  @post('/buckets', {
    responses: {
      '200': {
        description: 'Bucket creation response',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                Location: {type: 'string'},
                headers: {
                  type: 'object',
                  properties: {
                    'Content-Type': {type: 'string'},
                  },
                },
              },
            },
          },
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              Name: {type: 'string'},
            },
          },
        },
      },
    })
    bucket: {Name: string},
  ): Promise<object> {
    if (bucket.Name == undefined) {
      var err = new HttpErrors.BadRequest('Name not found')
      throw (err)
    }
    var params = {
      Bucket: bucket.Name
    }
    try {
      const bucket = await s3.createBucket(params).promise()
      return bucket
    } catch (err) {
      throw err
    }
  }

  @del('/buckets/{bucketName}', {
    responses: {
      '204': {
        description: 'Bucket DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('bucketName') bucket: string): Promise<void> {
    var params = {
      Bucket: bucket
    }
    try {
      await s3.deleteBucket(params).promise()
      return
    } catch (err) {
      throw err
    }
  }

  @post('/buckets/{bucketName}/upload', {
    responses: {
      200: {
        content: {
          'application/json': {
            schema: {
              type: 'object',
            },
          },
        },
        description: '',
      },
    },
  })
  async upload(@param.path.string('bucketName') bucketName: string,
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          // Skip body parsing
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      const storage = multer.memoryStorage()
      const upload = multer({storage})
      upload.any()(request, response, async err => {
        if (err) reject(err)
        else {
          let res = new Array()
          for (const file of (request as any).files) {
            const params = {
              Bucket: bucketName,
              Key: file.originalname, // File name you want to save as in S3
              Body: bufferToStream(file.buffer)
            }
            try {
              const stored = await s3.upload(params).promise()
              res.push(stored)
            } catch (err) {
              reject(err)
            }
          }
          resolve(res)
        }
      })
    })
  }


  @post('/itemImage/upload/{itemId}/{index}', {
    responses: {
      200: {
        content: {
          'application/json': {
            schema: {
              type: 'object',
            },
          },
        },
        description: '',
      },
    },
  })
  async uploadItemImage(@param.path.string('itemId') itemId: string,
    @param.path.string('index') index: string,
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          // Skip body parsing
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      const storage = multer.memoryStorage()
      const upload = multer({storage})
      const bucketName = "cinemate.bucket"
      const folderName = "itemImages/"
      upload.any()(request, response, async err => {
        if (err) reject(err)
        else {
          let res = new Array()
          for (const file of (request as any).files) {
            const params = {
              Bucket: bucketName,
              Key: folderName + file.originalname, // File name you want to save as in S3
              Body: bufferToStream(file.buffer)
            }
            try {
              const stored = await s3.upload(params).promise()
              //res.push(stored)
              console.log(stored);

              var image = new ItemImage()
              image.url = stored.Location;
              image.bucketKey = stored.Key;
              image.itemId = itemId;
              image.order = Number.parseInt(index);
              res.push(await this.itemImageRepository.create(image));
            } catch (err) {
              reject(err)
            }
          }
          let custRes = new CustomResponse({success: true, data: res});
          resolve(custRes)
        }
      })
    })
  }

  @post('/deleteItemImage/{itemId}', {
    responses: {
      200: {
        content: {
          'application/json': {
            schema: {
              type: 'object',
            },
          },
        },
        description: '',
      },
    },
  },)
  async deleteItemImage(@param.path.string('itemId') itemId: string,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              id: {type: 'string'},
              key: {type: 'string'},
              index: {type: 'number'},
            },
          },
        },
      },
    })
    request: {id: string, key: string, index: number},
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<object> {
    return new Promise<object>(async (resolve, reject) => {
      const bucketName = "cinemate.bucket"

      const params = {
        Bucket: bucketName,
        Key: request.key
      }
      let custRes = new CustomResponse();
      try {
        s3.deleteObject(params, async (error, data) => {
          if (error) {
            custRes.success = false;
            custRes.message = "Error deleting file";
            custRes.data = error;
            console.log(error)
            reject(custRes)
          }
          else {
            custRes.success = true;
            custRes.message = "File has been deleted successfully";
            await this.itemImageRepository.deleteById(request.id)
            var items = await this.itemImageRepository.find({where: {itemId: itemId, order: {gt: request.index}}})
            items.forEach(element => {
              this.itemImageRepository.updateById(element.id, {order: element.order ?? 0 - 1})
            });
            resolve(custRes)
          }
        });
      } catch (err) {
        reject(err)
      }
    })
  }

  @post('/profileImage/upload/{merchantId}', {
    responses: {
      200: {
        content: {
          'application/json': {
            schema: {
              type: 'object',
            },
          },
        },
        description: '',
      },
    },
  })
  async uploadProfileImage(@param.path.string('merchantId') merchantId: string,
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          // Skip body parsing
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<object> {
    return new Promise<object>((resolve, reject) => {
      const storage = multer.memoryStorage()
      const upload = multer({storage})
      const bucketName = "cinemate.bucket"
      const folderName = "profileImages/"
      upload.any()(request, response, async err => {
        if (err) reject(err)
        else {
          let res = new Array()
          for (const file of (request as any).files) {
            const params = {
              Bucket: bucketName,
              Key: folderName + file.originalname, // File name you want to save as in S3
              Body: bufferToStream(file.buffer)
            }
            try {
              const stored = await s3.upload(params).promise()
              res.push(stored)

              let merchResp = await this.merchantRepository.findById(merchantId);
              if (merchResp.imageKey != null)
                try {
                  const params = {
                    Bucket: bucketName,
                    Key: merchResp.imageKey
                  }
                  let custRes = new CustomResponse();
                  s3.deleteObject(params, (error, data) => {
                    if (error) {
                      custRes.success = false;
                      custRes.message = "Error deleting file";
                      custRes.data = error;
                    }
                    else {
                      custRes.success = true;
                      custRes.message = "File has been deleted successfully";
                    }
                  });
                } catch (err) {

                }
              await this.merchantRepository.updateById(merchantId, {imageKey: stored.Key, image: stored.Location});

              let custRes = new CustomResponse({success: true, data: {imageKey: stored.Key, image: stored.Location}});
              resolve(custRes)
            } catch (err) {
              reject(err)
            }
          }
        }
      })
    })
  }
}
 */
