import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  requestBody,
  response
} from '@loopback/rest';
import {Banner} from '../models';
import {CustomResponse} from '../models/response.model';
import {BannerRepository} from '../repositories';

export class BannerController {
  constructor(
    @repository(BannerRepository)
    public bannerRepository: BannerRepository,
  ) { }

  @post('addBanner')
  @response(200, {
    description: 'Banner model instance',
    content: {'application/json': {schema: getModelSchemaRef(Banner)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Banner, {
            title: 'NewBanner',
            exclude: ['id'],
          }),
        },
      },
    })
    banner: Omit<Banner, 'id'>,
  ): Promise<CustomResponse> {
    var res = await this.bannerRepository.create(banner);
    return new CustomResponse({success: true, data: res, message: "Banner added successfully"})
  }

  @get('/banners/count')
  @response(200, {
    description: 'Banner model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Banner) where?: Where<Banner>,
  ): Promise<Count> {
    return this.bannerRepository.count(where);
  }

  @get('/getBanners')
  @response(200, {
    description: 'Array of Banner model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Banner, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Banner) filter?: Filter<Banner>,
  ): Promise<CustomResponse> {
    var res = await this.bannerRepository.find({
      order: ['order ASC']
    });
    return new CustomResponse({success: true, data: res, })
  }

  @patch('/updateAllBanners')
  @response(200, {
    description: 'Banner PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Banner, {partial: true}),
        },
      },
    })
    banner: Banner,
    @param.where(Banner) where?: Where<Banner>,
  ): Promise<CustomResponse> {
    var res = await this.bannerRepository.updateAll(banner, where);
    return new CustomResponse({success: true, data: res, message: "Banner added successfully"})
  }

  @get('/getBanner/{id}')
  @response(200, {
    description: 'Banner model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Banner, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Banner, {exclude: 'where'}) filter?: FilterExcludingWhere<Banner>
  ): Promise<CustomResponse> {
    var res = await this.bannerRepository.findById(id, filter);
    return new CustomResponse({success: true, data: res, })
  }

  @patch('/updateBanner/{id}')
  @response(204, {
    description: 'Banner PATCH success',
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Banner, {partial: true}),
        },
      },
    })
    banner: Banner,
  ): Promise<CustomResponse> {
    var res = await this.bannerRepository.updateById(id, banner);
    return new CustomResponse({success: true, data: res, message: "Banner updated successfully"})
  }

  @del('/deleteBanner/{id}')
  @response(204, {
    description: 'Banner DELETE success',
  })
  async deleteById(@param.path.string('id') id: string): Promise<CustomResponse> {
    var res = await this.bannerRepository.deleteById(id);
    return new CustomResponse({success: true, message: "Banner deleted successfully"})
  }
}
