import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {
  Filter,
  FilterExcludingWhere,
  repository
} from '@loopback/repository';
import {
  HttpErrors,
  RequestContext,
  RestBindings,
  del, get,
  getModelSchemaRef,
  param, patch, post,
  requestBody,
  response
} from '@loopback/rest';
import {SecurityBindings, UserProfile, securityId} from '@loopback/security';
import {FeedPost, FeedPostImage, FeedPostInsert} from '../models';
import {FeedPostImageRepository, FeedPostRepository, PostLikeRepository, ProfileRepository} from '../repositories';

export class FeedPostController {
  constructor(
    @repository(FeedPostRepository)
    public feedpostRepository: FeedPostRepository,
    @repository(FeedPostImageRepository)
    public feedpostImageRepository: FeedPostImageRepository,
    @repository(PostLikeRepository)
    public postLikeRepository: PostLikeRepository,
    @repository(ProfileRepository)
    public profileRepository: ProfileRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext
  ) { }

  @authenticate('jwt')
  @get('/getFeedPosts')
  async getFeedPosts(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.object('filter') filter?: Filter<FeedPost>,
  ): Promise<any[]> {
    const userId = currentUser?.[securityId];
    if (!userId) {
      throw new HttpErrors.Unauthorized('User not authenticated');
    }

    var resp = await this.feedpostRepository.find({
      include: ['images', 'user', 'likes'],
      order: ['dateCreated DESC'],
    });

    const postsWithLikeStatus = await Promise.all(
      resp.map(async post => {
        const like = await this.postLikeRepository.findOne({
          where: {userId, feedPostId: post.id},
        });
        var reactionCounts = {};
        if (post.likes != null && post.likes.length > 0) {
          reactionCounts = post.likes.reduce(
            (acc, like) => {
              const type = like.type || 'like';
              acc[type] = (acc[type] || 0) + 1;
              return acc;
            },
            {} as {[key: string]: number},
          );
        }
        return {
          ...post,
          hasLiked: like,
          reactionCounts: reactionCounts,
        };
      }),
    );
    return postsWithLikeStatus;
  }

  @authenticate('jwt')
  @get('/getFeedPosts/{userId}')
  async getFeedPost(
    @param.path.string('userId') userId: string,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.object('filter') filter?: Filter<FeedPost>,
  ): Promise<any[]> {
    const currentUserId = currentUser?.[securityId];
    if (!currentUserId) {
      throw new HttpErrors.Unauthorized('User not authenticated');
    }

    var resp = await this.feedpostRepository.find({
      where: {userId: userId},
      include: ['images', 'user', 'likes'],
      order: ['dateCreated DESC'],
    });
    const postsWithLikeStatus = await Promise.all(
      resp.map(async post => {
        const like = await this.postLikeRepository.findOne({
          where: {userId: currentUserId, feedPostId: post.id},
        });
        var reactionCounts = {};
        if (post.likes != null && post.likes.length > 0) {
          reactionCounts = post.likes.reduce(
            (acc, like) => {
              const type = like.type || 'like';
              acc[type] = (acc[type] || 0) + 1;
              return acc;
            },
            {} as {[key: string]: number},
          );
        }
        return {
          ...post,
          hasLiked: like,
          reactionCounts: reactionCounts,
        };
      }),
    );
    return postsWithLikeStatus;
  }

  @get('/getUserPosts/{id}')
  async getFeedPostsUser(
    @param.path.string('id') id: string,
    @param.query.object('filter') filter?: Filter<FeedPost>,
  ): Promise<any[]> {
    var resp = await this.feedpostRepository.find({
      where: {userId: id},
      include: ['images', {relation: 'likes', scope: {where: {customerId: id}, }}],
      order: ['dateCreated DESC'],
    });
    return resp;
  }

  @get('/getFeedPost/{id}')
  async findById(
    @param.path.string('id') id: string,
    @param.filter(FeedPost, {exclude: 'where'}) filter?: FilterExcludingWhere<FeedPost>
  ): Promise<FeedPost> {
    var res = await this.feedpostRepository.findById(id, {
      include: ['category', 'merchant', 'feedpostStatus', 'feedpostSize', 'images', 'allergens']
    });
    return res;
  }

  @post('/addFeedPost')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FeedPostInsert, {
            title: 'NewFeedPost',
          }),
        },
      },
    })
    feedpost: FeedPostInsert,
  ): Promise<FeedPost> {
    var feedpostTemp = feedpost;
    var res = await this.feedpostRepository.create(feedpost.feedpost!);
    feedpost.images?.forEach(async element => {
      await this.feedpostImageRepository.create(new FeedPostImage({url: element, feedPostId: res.id}))
    });
    var count = await this.feedpostRepository.count({userId: res.userId});
    await this.profileRepository.updateById(res.userId, {postCount: count.count});
    this.ctx.bind('response.message').to('Feed post created successfully');
    return res;
  }

  @patch('/updateFeedPost/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FeedPostInsert, {partial: true}),
        },
      },
    })
    feedpost: FeedPostInsert,
  ): Promise<void> {
    await this.feedpostRepository.updateById(id, feedpost.feedpost!);
    await this.feedpostImageRepository.deleteAll({feedPostId: id});
    feedpost.images?.forEach(async element => {
      await this.feedpostImageRepository.create(new FeedPostImage({url: element, feedPostId: id}))
    });
    this.ctx.bind('response.message').to('Feed post updated successfully');
    return;
  }

  @patch('/updateAllFeedPost')
  async updateAllFeedPost(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FeedPost, {partial: true}),
        },
      },
    })
    feedpost: FeedPost,
  ): Promise<void> {
    await this.feedpostRepository.updateAll(feedpost);
    this.ctx.bind('response.message').to('Feed posts updated successfully');
    return;
  }

  @del('/deleteFeedPost/{id}')
  @response(204, {
    description: 'FeedPost DELETE success',
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    var res = await this.feedpostRepository.findById(id);
    await this.feedpostRepository.deleteById(id);
    await this.feedpostImageRepository.deleteAll({feedPostId: id});
    var count = await this.feedpostRepository.count({userId: res.userId});
    await this.profileRepository.updateById(res.userId, {postCount: count.count});
    this.ctx.bind('response.message').to('Post deleted successfully');
    return;
  }
}
