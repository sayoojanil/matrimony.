import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {get, HttpErrors, param, post, requestBody, RequestContext, RestBindings} from '@loopback/rest';
import {SecurityBindings, securityId, UserProfile} from '@loopback/security';
import {Follower} from '../models/follower.model';
import {ProfileRepository, UserRepository} from '../repositories';
import {FollowerRepository} from '../repositories/follower.repository';

export class FollowerController {
  constructor(
    @repository(FollowerRepository)
    public followerRepository: FollowerRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @repository(ProfileRepository)
    public profileRepository: ProfileRepository,
    @inject(SecurityBindings.USER, {optional: true})
    public currentUser: UserProfile,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext,
  ) { }

  @authenticate('jwt')
  @post('/followers/follow', {
    responses: {
      '200': {
        description: 'Follow a user',
        content: {
          'application/json': {schema: {type: 'object'}},
        },
      },
    },
  })
  async follow(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['followedId'],
            properties: {
              followedId: {type: 'string'},
            },
          },
        },
      },
    })
    body: {followedId: string},
  ): Promise<void> {
    if (!this.currentUser || !this.currentUser[securityId]) {
      throw new HttpErrors.Unauthorized('Unauthorized');
    }

    const followerId = this.currentUser[securityId];

    if (followerId === body.followedId) {
      throw new HttpErrors.BadRequest('Cannot follow yourself');
    }

    const followedUser = await this.userRepository.findById(body.followedId);
    if (!followedUser) {
      throw new HttpErrors.NotFound('User to follow not found');
    }

    const existingFollow = await this.followerRepository.findOne({
      where: {followerId, followedId: body.followedId},
    });
    if (existingFollow) {
      throw new HttpErrors.BadRequest('Already following this user');
    }

    const follower = new Follower({
      followerId,
      followedId: body.followedId,
      createdAt: new Date(),
    });

    try {
      await this.followerRepository.create(follower);
      var following = await this.followerRepository.count({followerId: followerId});
      await this.profileRepository.updateById(followerId, {following: following.count});

      var followers = await this.followerRepository.count({followedId: body.followedId});
      await this.profileRepository.updateById(body.followedId, {followers: followers.count});
      this.ctx.bind('response.message').to('Successfully followed user');
      return;
    } catch (error) {
      throw new HttpErrors.InternalServerError('Failed to follow user');
    }
  }

  @authenticate('jwt')
  @post('/followers/unfollow', {
    responses: {
      '200': {
        description: 'Unfollow a user',
        content: {
          'application/json': {schema: {type: 'object'}},
        },
      },
    },
  })
  async unfollow(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['followedId'],
            properties: {
              followedId: {type: 'string'},
            },
          },
        },
      },
    })
    body: {followedId: string},
  ): Promise<void> {
    if (!this.currentUser || !this.currentUser[securityId]) {
      throw new HttpErrors.Unauthorized('Unauthorized');
    }

    const followerId = this.currentUser[securityId];

    const existingFollow = await this.followerRepository.findOne({
      where: {followerId, followedId: body.followedId},
    });
    if (!existingFollow) {
      throw new HttpErrors.BadRequest('Not following this user');
    }

    try {
      await this.followerRepository.deleteById(existingFollow.id);

      var following = await this.followerRepository.count({followerId: followerId});
      await this.profileRepository.updateById(followerId, {following: following.count});

      var followers = await this.followerRepository.count({followedId: body.followedId});
      await this.profileRepository.updateById(body.followedId, {followers: followers.count});

      this.ctx.bind('response.message').to('Successfully unfollowed user');
      return;
    } catch (error) {
      throw new HttpErrors.InternalServerError('Failed to unfollow user');
    }
  }

  @get('/followers/{userId}/followers', {
    responses: {
      '200': {
        description: 'Get list of followers for a user',
        content: {
          'application/json': {schema: {type: 'object'}},
        },
      },
    },
  })
  async getFollowers(
    @param.path.string('userId') userId: string,
  ): Promise<any[]> {
    try {
      const followers = await this.followerRepository.find({
        where: {followedId: userId},
      });

      const followerIds = followers.map(f => f.followerId);
      const profiles = await this.profileRepository.find({
        where: {userId: {inq: followerIds}},
      });

      this.ctx.bind('response.message').to('Followers retrieved successfully');
      return profiles;
    } catch (error) {
      throw new HttpErrors.InternalServerError('Failed to retrieve followers');
    }
  }

  @get('/followers/{userId}/following', {
    responses: {
      '200': {
        description: 'Get list of users a user is following',
        content: {
          'application/json': {schema: {type: 'object'}},
        },
      },
    },
  })
  async getFollowing(
    @param.path.string('userId') userId: string,
  ): Promise<any[]> {
    try {
      const following = await this.followerRepository.find({
        where: {followerId: userId},
      });

      const followedIds = following.map(f => f.followedId);
      const profiles = await this.profileRepository.find({
        where: {userId: {inq: followedIds}},
      });

      this.ctx.bind('response.message').to('Following list retrieved successfully');
      return profiles;
    } catch (error) {
      throw new HttpErrors.InternalServerError('Failed to retrieve following list');
    }
  }
}
