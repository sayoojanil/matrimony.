import {
  Count,
  CountSchema,
  Filter, repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  put, requestBody,
  response
} from '@loopback/rest';
import {MasterOption} from '../models';
import {ItemStatusRepository} from '../repositories';

export class MasterOptionController {
  constructor(
    @repository(ItemStatusRepository)
    public itemStatusRepository: ItemStatusRepository,
  ) { }


  @get('/getItemStatusCount')
  @response(200, {
    description: 'Item model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async getItemStatusCount(
    @param.where(MasterOption) where?: Where<MasterOption>,
  ): Promise<Count> {
    return this.itemStatusRepository.count(where);
  }

  @get('/getItemStatus')
  @response(200, {
    description: 'Array of Item model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(MasterOption, {includeRelations: true}),
        },
      },
    },
  })
  async getItemStatus(
    @param.filter(MasterOption) filter?: Filter<MasterOption>,
  ): Promise<MasterOption[]> {
    return this.itemStatusRepository.find(filter);
  }

  @put('/updateItemStatus/{id}')
  @response(204, {
    description: 'Item PUT success',
  })
  async updateItemStatus(
    @param.path.string('id') id: string,
    @requestBody() item: MasterOption,
  ): Promise<void> {
    await this.itemStatusRepository.replaceById(id, item);
  }

  @del('/deleteItemStatus/{id}')
  @response(204, {
    description: 'Item DELETE success',
  })
  async deleteItemStatus(@param.path.string('id') id: string): Promise<void> {
    await this.itemStatusRepository.deleteById(id);
  }
  //end for itemstatus


  /*
    @get('/getSearchItemFilter')
    async getSearchItemFilter(): Promise<any> {
      var response = new CustomResponse({
        success: true,
        data: {
          category: await this.categoryRepository.find(),
          itemStatus: await this.itemStatusRepository.find(),
          cinemates: await this.merchantRepository.find()
        }
      });
      return response;
    }


    @get('/getHomeItems')
    async getHomeItems(): Promise<any> {

      var carousel = [{
        name: "one",
        image: "https://media.istockphoto.com/id/1093110112/photo/picturesque-morning-in-plitvice-national-park-colorful-spring-scene-of-green-forest-with-pure.jpg?s=612x612&w=0&k=20&c=lpQ1sQI49bYbTp9WQ_EfVltAqSP1DXg0Ia7APTjjxz4="
      },
      {
        name: "two",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCZlf5lc5tX-0gY-y94pGS0mQdL-D0lCH2OQ&usqp=CAU"
      },
      {
        name: "three",
        image: "https://img.freepik.com/free-photo/painting-mountain-lake-with-mountain-background_188544-9126.jpg?q=10&h=200"
      },]
      var response = new CustomResponse({
        success: true,
        data: {
          carousel: carousel,
          category: await this.categoryRepository.find(),
          itemStatus: await this.itemStatusRepository.find(),
        }
      });
      return response;
    } */
}
