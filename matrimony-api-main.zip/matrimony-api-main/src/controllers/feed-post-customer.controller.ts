import {inject} from '@loopback/core';
import {
  CountSchema,
  Filter,
  repository,
  Where
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  post,
  requestBody,
  RequestContext,
  RestBindings
} from '@loopback/rest';
import {
  PostLike,
  Profile
} from '../models';
import {FeedPostRepository, PostLikeRepository} from '../repositories';

export class FeedPostCustomerController {
  constructor(
    @repository(FeedPostRepository) protected feedPostRepository: FeedPostRepository,
    @repository(PostLikeRepository) protected postLikeRepository: PostLikeRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext,
  ) { }

  @post('/addLike', {
    responses: {
      '200': {
        description: 'create a PostLike model instance',
        content: {'application/json': {schema: getModelSchemaRef(PostLike)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PostLike, {
            title: 'NewCustomerInFeedPost',
            exclude: ['id'],
          }),
        },
      },
    }) like: Omit<PostLike, 'id'>,
  ): Promise<PostLike> {
    var res = await this.postLikeRepository.create(like);
    var count = await this.postLikeRepository.count({feedPostId: like.feedPostId});
    await this.feedPostRepository.updateById(like.feedPostId, {likesCount: count.count});
    this.ctx.bind('response.message').to('Post liked');
    return res;
  }

  @get('/getPostLikes')
  async getFeedPostsUser(
    @param.query.object('filter') filter?: Filter<PostLike>,
  ): Promise<PostLike[]> {
    var resp = await this.postLikeRepository.find(filter);
    return resp;
  }


  @del('/deleteLike/{postId}/{userId}', {
    responses: {
      '200': {
        description: 'FeedPost.Customer DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.string('postId') postId: string,
    @param.path.string('userId') userId: string,
    @param.query.object('where', getWhereSchemaFor(Profile)) where?: Where<Profile>,
  ): Promise<void> {
    await this.postLikeRepository.deleteAll({userId: userId, feedPostId: postId});
    var count = await this.postLikeRepository.count({feedPostId: postId});
    await this.feedPostRepository.updateById(postId, {likesCount: count.count});
    this.ctx.bind('response.message').to('Like deleted successfully');
    return;
  }
}
