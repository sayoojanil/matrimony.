import {TokenService} from '@loopback/authentication';
import {TokenServiceBindings, UserServiceBindings} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {get, getModelSchemaRef, HttpErrors, param, patch, post, requestBody, RequestContext, RestBindings} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {AdminMaster} from '../models';
import {Profile} from '../models/profile.model';
import {UserCredentials} from '../models/user-credential.model';
import {User} from '../models/user.model';
import { } from '../repositories';
import {AdminRepository} from '../repositories/admin.repository';
import {ProfileRepository} from '../repositories/profile.repository';
import {UserRepository} from '../repositories/user.repository';
import {CustomUserService} from '../services/user.service';

export class UserController {
  constructor(
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: TokenService,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: CustomUserService,
    @inject(SecurityBindings.USER, {optional: true})
    public user: UserProfile,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @repository(ProfileRepository)
    public profileRepository: ProfileRepository,
    @repository(AdminRepository)
    public adminRepository: AdminRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext
  ) { }

  @post('/user/login')
  async login(
    @requestBody({
      description: 'The input of login function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['username'],
            properties: {
              username: {
                type: 'string'
              }
            },
          }
        },
      },
    }) credential: UserCredentials,
  ): Promise<void> {
    const profile = await this.userRepository.findOne({
      where: {username: credential.username, userType: 1},
    });
    if (profile == null) {
      throw new HttpErrors.Unauthorized('Invalid user');
    } else {
      var otp = credential.username!.substring(0, 4);
      try {
        this.userRepository.updateById(profile.id, {otp: otp});
        setTimeout(() => {
          try {
            this.userRepository.updateById(profile.id, {otp: ''});
          } catch { }
        }, 3 * 60 * 1000);
      } catch { }
      this.ctx.bind('response.message').to('OTP sent to your phone number');
      return;
    }
  }

  @post('/user/loginWithEmail')
  async loginWithEmail(
    @requestBody({
      description: 'The input of login function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['email', 'password'],
            properties: {
              email: {
                type: 'string'
              },
              password: {
                type: 'string'
              }
            },
          }
        },
      },
    }) credential: {
      email: string,
      password: string,
    },
  ): Promise<{token: string, user: Profile | null}> {
    const user = await this.userRepository.findOne({
      where: {email: credential.email, password: credential.password, userType: 1},
    });
    if (user == null) {
      throw new HttpErrors.Unauthorized('Incorrect email or password');
    } else {
      var userOtp = await this.userRepository.findOne({
        where: {email: credential.email},
      });
      if (userOtp == null) {
        throw new HttpErrors.Unauthorized('Invalid user');
      }
      const userProfile = this.userService.convertToUserProfile(userOtp)
      const token = await this.jwtService.generateToken(userProfile);

      var profile = await this.profileRepository.findOne({
        where: {email: credential.email},
      });

      this.ctx.bind('response.message').to('Login successful');
      return {
        token: token,
        user: profile,
      };
    }
  }

  @post('/user/loginWithGoogle')
  async loginWithGoogle(
    @requestBody({
      description: 'The input of login function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['email', 'token'],
            properties: {
              email: {
                type: 'string'
              },
              token: {
                type: 'string'
              }
            },
          }
        },
      },
    }) credential: {
      email: string,
      token: string,
    },
  ): Promise<{token: string, user: Profile | null}> {
    const user = await this.userRepository.findOne({
      where: {email: credential.email, userType: 1},
    });
    if (user == null) {
      throw new HttpErrors.Unauthorized('Invalid user email');
    } else {
      var userOtp = await this.userRepository.findOne({
        where: {email: credential.email},
      });
      if (userOtp == null) {
        throw new HttpErrors.Unauthorized('Invalid user email');
      }
      const userProfile = this.userService.convertToUserProfile(userOtp)
      const token = await this.jwtService.generateToken(userProfile);

      var profile = await this.profileRepository.findOne({
        where: {email: credential.email},
      });
      this.ctx.bind('response.message').to('Login successful');
      return {
        token: token,
        user: profile,
      };
    }
  }

  @post('/admin/login')
  async adminLogin(
    @requestBody({
      description: 'The input of login function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['email', 'password'],
            properties: {
              email: {
                type: 'string'
              },
              password: {
                type: 'string'
              }
            },
          }
        },
      },
    }) credential: {
      email: string,
      password: string,
    },
  ): Promise<{token: string, user: AdminMaster | null}> {
    const user = await this.userRepository.findOne({
      where: {email: credential.email, password: credential.password, userType: 2},
    });
    if (user == null) {
      throw new HttpErrors.Unauthorized('Incorrect email or password');
    } else {
      var userOtp = await this.userRepository.findOne({
        where: {email: credential.email},
      });
      if (userOtp == null) {
        throw new HttpErrors.Unauthorized('Invalid otp');
      }
      const userProfile = this.userService.convertToUserProfile(userOtp)
      const token = await this.jwtService.generateToken(userProfile);

      var profile = await this.adminRepository.findOne({
        where: {email: credential.email},
      });
      this.ctx.bind('response.message').to('Login successful');
      return {
        token: token,
        user: profile,
      };
    }
  }

  @post('/users/verifyOtp')
  async verifyOtp(
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['username', 'otp'],
            properties: {
              username: {
                type: 'string'
              },
              otp: {
                type: 'string'
              },
            },
          }
        },
      },
    }) credential: UserCredentials,
  ): Promise<{token: string, user: Profile | null}> {
    var userOtp = await this.userRepository.findOne({
      where: {username: credential.username, otp: credential.otp, userType: 1},
    });
    if (userOtp == null) {
      throw new HttpErrors.Unauthorized('Invalid otp');
    } else {
      const userProfile = this.userService.convertToUserProfile(userOtp)
      const token = await this.jwtService.generateToken(userProfile);
      var profile = await this.profileRepository.findOne({
        where: {phone: credential.username},
      });
      this.ctx.bind('response.message').to('Login successful');
      this.userRepository.updateById(userOtp.id, {otp: ''});
      return {
        token: token,
        user: profile,
      };
    }
  }

  @post('/users/signup')
  async signup(
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              phone: {
                type: 'string'
              },
              email: {
                type: 'string'
              },
              name: {
                type: 'string'
              },
              password: {
                type: 'string'
              },
            },
          }
        },
      },
    }) credential: {
      phone: string,
      email: string,
      name: string,
      password: string,
    },
  ): Promise<{token: string, user: Profile}> {
    const profile = new Profile();
    profile.phone = credential.phone;
    profile.email = credential.email;
    profile.name = credential.name;

    const exisitingProfile = await this.profileRepository.findOne({
      where: {or: [{phone: credential.phone}, {email: credential.email}]},
    });

    if (exisitingProfile != null) {
      let str: string[] = [];
      let data: Map<string, any> = new Map()
      if (exisitingProfile.phone == credential.phone) {
        str.push('Account with this phone number already exist')
        data.set('phoneExits', true);
      }
      if (exisitingProfile.email == credential.email) {
        str.push('Account with this email already exist')
        data.set('emailExits', true);
      }
      this.ctx.bind('response.data').to(data);
      throw new HttpErrors.BadRequest(str.join(' and '));
    }
    var res = await this.profileRepository.create(profile);

    const user = new User();
    user.username = credential.phone!;
    user.email = credential.email!;
    user.id = res.id!.toString();
    user.userType = 1;
    user.password = credential.password!;
    user.otp = credential.phone!.substring(0, 4);
    var userResp;
    try {
      userResp = await this.userRepository.create(user)
    } catch {
      this.userRepository.replaceById(user.id, user)
    }

    profile.userId = userResp!.id;
    await this.profileRepository.updateById(res.id, profile)
    const userProfile = this.userService.convertToUserProfile(userResp!)
    const token = await this.jwtService.generateToken(userProfile);
    this.ctx.bind('response.message').to('User created succesfully');
    return {
      token: token,
      user: res,
    };
  }

  @post('/admin/create')
  async adminCreate(
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['phone', 'email', 'name', 'password'],
            properties: {
              phone: {
                type: 'string'
              },
              email: {
                type: 'string'
              },
              name: {
                type: 'string'
              },
              password: {
                type: 'string'
              },
              userAccess: {
                type: 'boolean'
              },
              editItem: {
                type: 'boolean'
              },
              editPlan: {
                type: 'boolean'
              },
              editPromotion: {
                type: 'boolean'
              },
              approval: {
                type: 'boolean'
              },
            },
          }
        },
      },
    }) credential: {
      phone: string,
      email: string,
      name: string,
      password: string,
      userAccess: boolean,
      editItem: boolean,
      editPlan: boolean,
      editPromotion: boolean,
      approval: boolean,
    },
  ): Promise<AdminMaster> {
    const profile = new AdminMaster();
    profile.phone = credential.phone;
    profile.email = credential.email;
    profile.name = credential.name;
    profile.userAccess = credential.userAccess;
    profile.editItem = credential.editItem;
    profile.editPlan = credential.editPlan;
    profile.editPromotion = credential.editPromotion;
    profile.approval = credential.approval;

    const exisitingProfile = await this.adminRepository.findOne({
      where: {or: [{phone: credential.phone}, {email: credential.email}]},
    });

    if (exisitingProfile != null) {
      let str: string[] = [];
      let data: Map<string, any> = new Map()
      if (exisitingProfile.phone == credential.phone) {
        str.push('Account with this phone number already exist')
        data.set('phoneExits', true);
      }
      if (exisitingProfile.email == credential.email) {
        str.push('Account with this email already exist')
        data.set('emailExits', true);
      }
      this.ctx.bind('response.data').to(data);
      throw new HttpErrors.BadRequest(str.join(' and '));
    }
    var res = await this.adminRepository.create(profile);

    const user = new User();
    user.username = credential.phone!;
    user.email = credential.email!;
    user.id = res.id!.toString();
    user.userType = 2;
    user.password = credential.password!;
    user.otp = credential.phone!.substring(0, 4);
    var userResp;
    try {
      userResp = await this.userRepository.create(user)
    } catch {
      user.userType = 3;
      this.userRepository.replaceById(user.id, user)
    }

    profile.userId = userResp!.id;
    await this.adminRepository.updateById(res.id, profile)
    this.ctx.bind('response.message').to('Admin created successgully');
    return res;
  }

  @post('/changePassword')
  async changePassword(
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['id', 'userType', 'oldPassword', 'password'],
            properties: {
              id: {
                type: 'string'
              },
              oldPassword: {
                type: 'string'
              },
              userType: {
                type: 'number'
              },
              password: {
                type: 'string'
              }
            },
          }
        },
      },
    }) credential: {
      id: string,
      userType: number,
      oldPassword: string,
      password: string,
    },
  ): Promise<void> {
    const profile = new User();
    profile.password = credential.password;

    const exisitingProfile = await this.userRepository.findOne({
      where: {and: [{id: credential.id}, {password: credential.oldPassword}, {userType: credential.userType}]},
    });

    if (exisitingProfile == null) {
      throw new HttpErrors.Unauthorized("Incorrect password");
    }
    await this.userRepository.updateById(credential.id, profile);
    this.ctx.bind('response.message').to('Password changed successfully');
    return;
  }

  @post('/users/update/{id}')
  async updateProfile(
    @param.path.string('id') id: string,
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['phone', 'email', 'name', 'dob', 'gender'],
            properties: {
              phone: {
                type: 'string'
              },
              email: {
                type: 'string'
              },
              name: {
                type: 'string'
              },
              dob: {
                type: 'string'
              },
              gender: {
                type: 'string'
              },
            },
          }
        },
      },
    }) credential: {
      phone: string,
      email: string,
      name: string,
      dob: string,
      gender: string,
    },
  ): Promise<Profile> {
    const profile = new Profile();
    profile.phone = credential.phone;
    profile.email = credential.email;
    profile.name = credential.name;
    profile.dob = credential.dob;
    profile.gender = credential.gender;

    const exisitingProfile = await this.profileRepository.findOne({
      where: {or: [{phone: credential.phone}, {email: credential.email}]},
    });

    if (exisitingProfile != null && exisitingProfile.id != id) {
      let str: string[] = [];
      let data: Map<string, any> = new Map()
      if (exisitingProfile.phone == credential.phone) {
        str.push('Account with this phone number already exist')
        data.set('phoneExits', true);
      }
      if (exisitingProfile.email == credential.email) {
        str.push('Account with this email already exist')
        data.set('emailExits', true);
      }
      this.ctx.bind('response.data').to(data);
      throw new HttpErrors.BadRequest(str.join(' and '));
    }
    await this.profileRepository.updateById(id, profile);
    var res = await this.profileRepository.findById(id);

    const user = new User();
    user.username = credential.phone!;
    user.email = credential.email!;
    user.otp = credential.phone!.substring(0, 4);
    await this.userRepository.updateById(id, user)

    this.ctx.bind('response.message').to('Profile updated successfully');
    return res;
  }

  @patch('/admin/update/{id}')
  async adminUpdate(
    @param.path.string('id') id: string,
    @requestBody({
      description: 'The input of otp verification function',
      required: true,
      content: {
        'application/json': {
          schema: getModelSchemaRef(AdminMaster, {partial: true}),
        },
      },
    }) credential: AdminMaster,
  ): Promise<AdminMaster> {
    const exisitingProfile = await this.adminRepository.findOne({
      where: {or: [{phone: credential.phone}, {email: credential.email}]},
    });

    if (exisitingProfile != null && exisitingProfile.id != id) {
      let str: string[] = [];
      let data: Map<string, any> = new Map()
      if (exisitingProfile.phone == credential.phone) {
        str.push('Account with this phone number already exist')
        data.set('phoneExits', true);
      }
      if (exisitingProfile.email == credential.email) {
        str.push('Account with this email already exist')
        data.set('emailExits', true);
      }
      this.ctx.bind('response.data').to(data);

      throw new HttpErrors.BadRequest(str.join(' and '));
    }
    await this.adminRepository.updateById(id, credential);
    var admin = await this.adminRepository.findById(id);

    const user = new User();
    user.username = credential.phone!;
    user.email = credential.email!;
    user.otp = credential.phone!.substring(0, 4);
    try {
      await this.userRepository.updateById(admin.userId!, user)
    } catch {
    }
    this.ctx.bind('response.message').to('Profile updated successfully');
    return admin;
  }

  @get('/users/details/{id}')
  async getUserDetails(
    @param.path.string('id') id: string,): Promise<{token: string, user: Profile}> {
    var profile = await this.profileRepository.findById(id);
    return {
      token: "",
      user: profile,
    };
  }

  @get('/admin/details/{id}')
  async getAdminDetails(
    @param.path.string('id') id: string,): Promise<{token: string, user: AdminMaster}> {
    var profile = await this.adminRepository.findById(id);
    return {
      token: "",
      user: profile,
    };
  }
}
