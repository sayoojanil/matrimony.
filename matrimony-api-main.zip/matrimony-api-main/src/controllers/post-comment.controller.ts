import {inject} from '@loopback/core';
import {
  Filter,
  FilterExcludingWhere,
  repository
} from '@loopback/repository';
import {
  RequestContext,
  RestBindings,
  del, get,
  getModelSchemaRef,
  param, patch, post,
  requestBody
} from '@loopback/rest';
import {PostComment} from '../models';
import {FeedPostRepository, PostCommentRepository} from '../repositories';

export class PostCommentController {
  constructor(
    @repository(PostCommentRepository)
    public postCommentRepository: PostCommentRepository,
    @repository(FeedPostRepository)
    public feedpostRepository: FeedPostRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext,
  ) { }

  @post('/postComment')
  async postComment(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PostComment, {
            title: 'NewReview',
            exclude: ['id'],
          }),
        },
      },
    })
    review: Omit<PostComment, 'id'>,
  ): Promise<PostComment> {
    const res = await this.postCommentRepository.create(review);
    const commentsCount = await this.postCommentRepository.count({feedPostId: review.feedPostId});
    await this.feedpostRepository.updateById(review.feedPostId, {commentsCount: commentsCount.count});
    this.ctx.bind('response.message').to('Comment added successfully');
    return res;
  }

  @get('/getPostComments/{feedPostId}')
  async getItemReviews(
    @param.path.string('feedPostId') feedPostId: string,
    @param.filter(PostComment) filter?: Filter<PostComment>,
  ): Promise<PostComment[]> {
    if (filter == null) {
      filter = {
        where: {feedPostId: feedPostId},
        include: ["user"]
      }
    }
    const res = await this.postCommentRepository.find(filter);
    return res;
  }

  @get('/getComment/{id}')
  async findById(
    @param.path.string('id') id: string,
    @param.filter(PostComment, {exclude: 'where'}) filter?: FilterExcludingWhere<PostComment>
  ): Promise<PostComment> {
    if (filter == null) {
      filter = {
        "include": ["user"]
      }
    }
    const res = await this.postCommentRepository.findById(id, filter);
    return res;
  }

  @patch('/editComment/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PostComment, {partial: true}),
        },
      },
    })
    review: PostComment,
  ): Promise<void> {
    await this.postCommentRepository.updateById(id, review);
    this.ctx.bind('response.message').to('Comment updated successfully');
    return;
  }

  @del('/deleteComment/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    const res = await this.postCommentRepository.findById(id);
    await this.postCommentRepository.deleteById(id);
    const commentsCount = await this.postCommentRepository.count({feedPostId: res.feedPostId});
    await this.feedpostRepository.updateById(res.feedPostId, {commentsCount: commentsCount.count});
    this.ctx.bind('response.message').to('Comment deleted successfully');
    return;
  }
}
