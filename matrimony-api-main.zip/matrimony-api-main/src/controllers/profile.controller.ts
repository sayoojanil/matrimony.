import {inject} from '@loopback/core';
import {
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  requestBody,
  RequestContext,
  response,
  RestBindings
} from '@loopback/rest';
import {Profile} from '../models';
import {ProfileRepository} from '../repositories';

export class CustomerController {
  constructor(
    @repository(ProfileRepository)
    public profileRepository: ProfileRepository,
    @inject(RestBindings.Http.CONTEXT)
    private ctx: RequestContext,
  ) { }

  @get('/customers/count')
  @response(200, {
    description: 'Customer model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Profile) where?: Where<Profile>,
  ): Promise<{count: number}> {
    var res = await this.profileRepository.count(where);
    return res;
  }

  @get('/getProfileMatches')
  @response(200, {
    description: 'Array of Customer model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Profile, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Profile) filter?: Filter<Profile>,
  ): Promise<Profile[]> {
    var res = await this.profileRepository.find(filter);
    return res;
  }

  @patch('/updateAllCustomers')
  @response(200, {
    description: 'Customer PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Profile, {partial: true}),
        },
      },
    })
    customer: Profile,
    @param.where(Profile) where?: Where<Profile>,
  ): Promise<{count: number}> {
    var res = await this.profileRepository.updateAll(customer, where);
    this.ctx.bind('response.message').to('Customers updated successfully');
    return res;
  }

  @get('/getProfile/{id}')
  @response(200, {
    description: 'Customer model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Profile, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Profile, {exclude: 'where'}) filter?: FilterExcludingWhere<Profile>
  ): Promise<Profile> {
    var res = await this.profileRepository.findById(id, filter);
    return res;
  }

  @patch('/updateProfile/{id}')
  @response(204, {
    description: 'Customer PATCH success',
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Profile, {partial: true}),
        },
      },
    })
    customer: Profile,
  ): Promise<Profile> {
    await this.profileRepository.updateById(id, customer);
    var res = await this.profileRepository.findById(id);
    this.ctx.bind('response.message').to('Customer updated successfully');
    return res;
  }

  @del('/deleteProfile/{id}')
  @response(204, {
    description: 'Customer DELETE success',
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.profileRepository.deleteById(id);
    this.ctx.bind('response.message').to('Customer deleted');
    return;
  }
}
